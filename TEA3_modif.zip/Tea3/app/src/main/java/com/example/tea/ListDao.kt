package com.example.tea

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ListDao {
    @Query("SELECT * FROM lists")
    fun getAllLists(): List<ListOfItems>

    @Query("SELECT * FROM items WHERE listId = :listId")
    fun getItemsForList(listId: String): List<ItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertList(list: ListOfItems)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertItem(item: ItemEntity)

}